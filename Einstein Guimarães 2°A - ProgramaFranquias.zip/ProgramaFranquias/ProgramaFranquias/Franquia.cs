﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramaFranquias
{
    internal class franquia
    {
        public string NomeFantasia { get; set; }
        public string tipoFranquia { get; set; }
        public double ValorRendimento { get; set; }
        public List<Funcionario> listaFuncionarios { get; set; }
        public double ValorPagar { get; private set; }

        public franquia(string nomeFantasia, string tipoFranquia)
        {
            NomeFantasia = nomeFantasia;
            tipoFranquia = tipoFranquia;
            listaFuncionarios = new List<Funcionario>();
            ValorRendimento = DefinirRendimento(tipoFranquia);
        }

        public double DefinirRendimento(string tipoFranquia)
        {
            return tipoFranquia switch
            {
                "Pequena" => 300000,
                "Média" => 600000,
                "Média alta" => 900000,
                "Alta" => 1200000,
                "Luxo" => 1800000,
            };
        }

        public void CalcularValorFranquia()
        {
            ValorPagar = listaFuncionarios.Count * ValorRendimento * 0.001;
        }

        public void AdicionarFuncionario(Funcionario funcionario)
        {
            if (listaFuncionarios.Count < 50)
            {
                listaFuncionarios.Add(funcionario);
                CalcularValorFranquia();
            }
            else
            {
                Console.WriteLine("Numero maximo de funcionarios.");
            }
        }
    }
}
