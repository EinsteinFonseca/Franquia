﻿using System;
using System.Collections.Generic;
using ProgramaFranquias;
using ProgramaFranquias;
class Program
{
    static List<franquia> franquias = new List<franquia>();

    static void Main(string[] args)
    {
        int opcao = 1;

        while (opcao != 0)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Programa criado por Einstein Guimarães da Fonseca ~ 2° informática");

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Sistema de Gestão de Franquias");
            Console.WriteLine("@@@@@@@@@@@@@ - MENU - @@@@@@@@@@@@");
            Console.WriteLine("1 - cadastrar Franquia");
            Console.WriteLine("2 - cadastrar funcionário");
            Console.WriteLine("3 - consultar funcionarios de uma franquia");
            Console.WriteLine("4 - consultar funcionario por nome");
            Console.WriteLine("5 - Filtrar funcionários por nome");
            Console.WriteLine("0 - sair do programa");
            Console.Write("escola uma opcao: ");

            opcao = Convert.ToInt32(Console.ReadLine());

            switch (opcao)
            {
                case 1:
                    CadastrarFranquia();
                    break;
                case 2:
                    CadastrarFuncionario();
                    break;
                case 3:
                    ConsultarFranquia();
                    break;
                case 4:
                    ConsultarFuncionarioNome();
                    break;
                case 5:
                    FiltrarFuncionariosPorNome();
                    break;
                case 6:
                    FiltrarFuncionarioPorSalario();
                    break;
                case 7:
                    FiltrarFranquiasTipo();
                    break;
                case 8:
                    
                    break;
                case 9:
                    ListarGerentes();
                    break;
                case 0:
                    Console.WriteLine("Sair do Programa");
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Opção inválida!");
                    break;
            }
            Console.ReadKey();
        }
    }// fim menu


    static void CadastrarFranquia()
    {
        Console.Clear();
        Console.WriteLine("@@@@@@@@@@@ CADASTRAR FRANQUIA @@@@@@@@@@@@@");
        Console.WriteLine();
        Console.Write("Nome Fantasia: ");
        string nomeFranquia = Console.ReadLine();

        Console.Write("Tipo de Franquia (Pequena, Média, Média Alta, Alta, Luxo.): ");
        string tipo = Console.ReadLine();

        Console.WriteLine();

        franquia novaFranquia = new franquia(nomeFranquia, tipo);
        franquias.Add(novaFranquia);

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Franquia cadastrada!");

    } // fim cadastro franquia



    static void CadastrarFuncionario()
    {
        Console.Clear();
        Console.WriteLine("@@@@@@@@@@@@@@ CADASTRAR FUNCIONARIO @@@@@@@@@@@@@@@@");
        Console.Write("Nome da Franquia: ");
        string nomeFranquia = Console.ReadLine();

        var franquiaAchada = franquias.FirstOrDefault(f => f.NomeFantasia == nomeFranquia); //Encontar nome da franquia


        if (franquiaAchada != null) // caso funcionario esteja na franquia
        {
            Console.Write("Nome do Funcionario: ");
            string nomeFuncionario = Console.ReadLine();
            Console.Write("Cargo (Gerente, Contador, secretario, vendedor, auxiliar de serviços gerais): ");
            string cargo = Console.ReadLine();
            Console.Write("Genero: ");
            string Genero = Console.ReadLine();
            Console.Write("CPF: ");
            double CPF = Convert.ToDouble(Console.ReadLine());


            Funcionario novoFuncionario = new Funcionario(nomeFuncionario, cargo);
            Console.WriteLine($"Funcionário {nomeFuncionario}");
            Console.WriteLine($"cargo na empresa {cargo}");
            Console.WriteLine($"Gênero {Genero}");
            Console.WriteLine($"CPF {CPF}");
            Console.WriteLine();

            franquia.Add.(Funcionario(novoFuncionario));


            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Funcionario cadastrado com sucesso!");

        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Franquia não encontrada!");
        }
    } // fim cadastrar funcionario



    static void ConsultarFranquia()
    {
        Console.Clear();
        Console.WriteLine("@@@@@@@@@@@ CONSULTAR FUNCIONARIOS DE UMA FRANQUIA @@@@@@@@@@@@@@@@");
        {
            Console.Clear();
            foreach (var franquia in franquias) // encontrar funcionario em franquias
            {
                Console.WriteLine($"Franquia: {franquia.NomeFantasia}");
                Console.WriteLine($"Tipo: {franquia.tipoFranquia}");
                Console.WriteLine($"Funcionários: {franquia.listaFuncionarios.Count}");
                Console.WriteLine();
            }
        }

    } //fim consultar funcionario



    static void ConsultarFuncionarioNome()
    {
        Console.Clear();
        Console.WriteLine("@@@@@@@@@@@@@@@@@@@@@ CONSULTAR FUNCIONARIO POR NOME @@@@@@@@@@@@@@@@@@@");

        Console.WriteLine("Digite o nome do funcionario que deseja Consultar");

        var lista = Funcionario.Where(p => p.nomeFuncionario == nome).ToList();

        if (funcionario != null)
        {
            Console.WriteLine($"Funcionario: {funcionario.Nome}");
            Console.WriteLine($"Cargo: {funcionario.Cargo}");
            Console.WriteLine($"Salário: {funcionario.salario}");
        }
        else
        {
            Console.BackgroundColor = ConsoleColor.Red;
            Console.WriteLine("Funcionário não encontrado.");
        }
    }// fim consultar funcionario por nome



    static void FiltrarFuncionariosPorNome()
    {
        Console.Clear();
        Console.WriteLine("@@@@@@@@@@@ FILTAR FUNCIONARIO POR NOME @@@@@@@@@@@@@@@@");
        Console.WriteLine("Digite o nome do funcionario");
        string nomeFuncionario = Console.ReadLine();

        var funcionariosFiltrados = franquias.Where(f => f.listaFuncionarios).Where(funcion => funcion.Nome.Contains(nomeFuncionario)).ToList();

        if (funcionariosFiltrados.FirstOrDefault())
        {
            Console.WriteLine("Funcionario encontrado:");
            foreach (var funcionario in funcionariosFiltrados)
            {
                Console.WriteLine($"Nome: {funcionario.Nome}");
                Console.WriteLine($"Cargo: {funcionario.Cargo}");
                Console.WriteLine($"Salário: {funcionario.salario}");
            }
        }
        else
        {
            Console.BackgroundColor = ConsoleColor.Red;
            Console.WriteLine("Nenhum funcionário encontrado.");
        }
    }// fim Funcionario



    static void FiltrarFuncionarioPorSalario()
    {
        Console.Clear();
        Console.WriteLine("@@@@@@@@@@@@@@ FILTRAR FUNCIONARIO POR SALARIO @@@@@@@@@@@@@@@@@");

        Console.Write("Salário: ");

        double salarioFuncion = Convert.ToDouble(Console.ReadLine());

        var funcionariosFiltrados = franquias.Where(f => f.listaFuncionarios).Where(funcion => funcion.salario >= salarioFuncion).ToList();



    }// fim salário


    static void FiltrarFranquiasTipo()
    {
        Console.Clear();
        Console.WriteLine("@@@@@@@@@@@@@@ FILTRAR FRANQUIAS POR TIPO @@@@@@@@@@@@@@@@@");

        Console.Clear();
        Console.Write("Digite o tipo de franquia: ");
        string tipoFranquia = Console.ReadLine();

        var franquiasFiltro = franquias.Where(f => f.tipoFranquia).ToList();


    }
   

    static void ListarGerentes()
    {
        // mostrar gerentes e onde atuam 
        Console.Clear();
        Console.WriteLine("@@@@@@@@@@@@@@@@ LISTAR GERENTES @@@@@@@@@@@@@@@@@@");
                
        Console.Clear();
        var gerentes = franquias.Where(f => f.listaFuncionarios).Where(funcion => funcion.Cargo("gerente")).ToList();

        if (gerentes.Where())
        {
            Console.WriteLine("Gerentes encontrados:");
            foreach (var gerente in gerentes)
            {
                Console.WriteLine($"Gerente: {gerente.Nome}");
                Console.WriteLine($"Cargo: {gerente.Cargo}");
                Console.WriteLine($"Salário: {gerente.salario}");
            }
        }
        else
        {
            Console.BackgroundColor = ConsoleColor.Red;
            Console.WriteLine("Nenhum gerente encontrado.");
        }
    }


}

}