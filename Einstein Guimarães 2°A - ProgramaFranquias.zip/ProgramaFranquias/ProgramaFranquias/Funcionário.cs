﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramaFranquias
{
    internal class Funcionario
    {
        public string Nome { get; set; }
        public string Cargo { get; set; }
        public double salario { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Genero { get; set; }
        public double CPF { get; set; }
                

        public Funcionario(string nome, string cargo)
        {
            Nome = nome;
            Cargo = cargo;
            salario = DefinirSalario(cargo);
        }

        private double DefinirSalario(string cargo)
        {
            return cargo switch
            {
                "gerente" => 12000,
                "contador" => 10000,
                "secretario" => 8000,
                "vendedor" => 5000,
                "auxiliar de serviços gerais" => 4500,
            };
        }
                
    }
}
